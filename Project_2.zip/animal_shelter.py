# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'Mytimehoney1337!' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None:
          try:

            self.database.animals.insert_one(data)  # data should be dictionary             
            return True
          except Exception as e:
        #Error Handling
        #If the DB is down or auth fails, we catch the crash here.
            print(f"An error occurred: {e}")
            return False
      
        else:
          return False

    def read(self, data):

      if data is not None:
        #self.collection.find(data)returns a 'Cursor' object.
        #Think of a cursor as a "pointer" to the data, not the data itself.
        cursor = self.collection.find(data, {'id':False})

        return list(cursor)
      
      else:
        return []

    def update(self, query, data):

      if query is not None:
        # Use the $set operator to update specific fields without overwriting the whole Document
        result = self.database.animals.update_many(query, {"$set": data})
        return result.modified_count
      
      else:
        return 0

    def delete(self, query):

      if query is not None:
        result = self.database.animals.delete_many(query)
        return result.deleted_count

      else:
        return 0